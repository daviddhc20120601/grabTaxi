import os
import logging.config
import time
#basepath = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
#logging.config.fileConfig('%s/logging.conf' % basepath)
logging.config.fileConfig('libs/logging.conf') 
logging.Formatter.converter = time.gmtime
logger = logging.getLogger(__name__)

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("dd").setLevel(logging.WARNING)
