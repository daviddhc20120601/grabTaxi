import os

dingding_access_token={
    'refund': '82e813aa8e55b0a0a01c2f3aa28657fb69c4f2d920e0b9cb8fb05f3b1bea6d64',
    'c360': '58b00d08c5fe8cae08815cb3dc80752a42eaa3601fecae8b1dd0c8bc647a6be7',
    'devops': 'c65d5cea4259a9da766c15e8791bae018354fea18437ec084057aa849a30c3e7'
}


proxies = {
  'http': 'http://alyn-srv-01031.lzd.io:8080',
  'https': 'http://alyn-srv-01031.lzd.io:8080',
}
if os.getenv('no_proxy'):
    if os.environ['no_proxy'].lower() == "yes":
        proxies = ''

