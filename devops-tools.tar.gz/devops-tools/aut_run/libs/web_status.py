import requests
import traceback
import json
import logging
import random
from settings import *
import time
import uuid
import os
logger = logging.getLogger(__name__)




def request_web(params):
    method=params['method']
    url=params['url']
    data=params['data']
    if params['auth']:
        (user,password)=params['auth'].split(':')
        auth=(user,password)
    else:
        auth=False
    status=params['status']
    log_id=uuid.uuid1()
    log_id=str(log_id).replace('-','')
    logger.info('log_id=%s start to test accessing url="%s"' % (log_id,url))
    logger.info("params='''%s'''" % json.dumps(params))
    start_time=time.time()

    msg=''
    try:

        if method.lower()=="get":
            if auth:
                response = requests.get(url,timeout=30,auth=auth)
            else:
                response = requests.get(url,timeout=30)

        elif method.lower()=="post":
            if 'virecognition' in url:
                response = requests.post(url,files=data,timeout=10,auth=auth)
            else:
                response = requests.post(url,data=data,timeout=10,auth=auth)
        status_code=response.status_code
        logger.info('status_code: %d' % status_code)


        if status:
            response_json=response.json()
            status=response_json['status']
            if status.lower() != "ok":
                msg=response_json['msg']
            else:
                msg=''
        else:
            status=''
            msg=''
    except:

        tb=traceback.format_exc()
        logger.error('log_id=%s exception caught when accessing url="%s"' % (log_id,url))
        logger.error('log_id=%s %s' % (log_id,tb))

        status_code=1000
        status=''
        msg='exception_caught'

    end_time=time.time()
    logger.info('log_id=%s trying to open url="%s" end' % (log_id,url))
    total_time=round((end_time-start_time)*1000,2)
    result={
        'status_code':status_code,
        'status':status,
        'msg':msg,
        'total_time':total_time
    }

    return (result)
