import requests
import traceback
import json
import logging
import random
from libs.settings import *
import smtplib
import time
import uuid
import pymysql
import sys
from influxdb import InfluxDBClient
from email.mime.text import MIMEText
import os


logging.getLogger('elasticsearch').setLevel(logging.WARN)

logger = logging.getLogger(__name__)


def sendmail(subject=None,to=None, content=None):

    msg=MIMEText(content,'html')
    msg['Subject'] = subject
    msg['From'] = "alert@static.visenze.com"
    tos=to.split(',')
    msg['To'] = to
    maillist=tos
    logger.info('sending email to %s with subject: %s' % (to, subject))
    s=smtplib.SMTP('email-smtp.us-east-1.amazonaws.com')
    s.starttls()
    s.login('AKIAIIG2K7NDS5CFLIHA','AkrqrqmATcqB7GsdQ1eDVeohan1Gfvq8zFZ0w4MfFdCQ')
    s.sendmail("alert@static.visenze.com",maillist,msg.as_string())
    s.quit()



def save_to_influxdb(db,json_body):
    if len(json_body)>0:
        client = InfluxDBClient('aut-dashboard.lzd.co', 8086, 'automation', 'Automation@Lazada', db)
        client.write_points(json_body)
        logger.info('load %d rows into influxdb %s' % (len(json_body), db))


def save_to_mysql(host, user, password, database, mysql_data, sql, tbl_name):
    connection = pymysql.connect(host=host,
                                 user=user,
                                 password=password,
                                 db=database)
    with connection.cursor() as cursor:
        number_of_row_affected = cursor.executemany(sql, mysql_data)
        logger.info('load %d rows into MySQL %s' % (number_of_row_affected, tbl_name))
    connection.commit()

def send_dingding_link(access_token,msg):
    headers = {"Content-Type": "application/json"}


    try:
        logger.info("sending dingding message %s" % json.dumps(msg))
        res=requests.post('https://oapi.dingtalk.com/robot/send?access_token=%s' % access_token, data=json.dumps(msg),headers=headers,proxies=proxies)
        if res.status_code != 200:
            logger.error("sending to dingtalk robot fail. status_code:%d text:%s" % (res.status_code, res.text))
        else:
            logger.info("sending to dingtalk robot successfully. ret code:%d" % res.status_code)

    except:
        tb = traceback.format_exc()
        logger.error(tb)


