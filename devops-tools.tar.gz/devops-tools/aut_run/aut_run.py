#-*-coding:utf-8-*-
import os,sys
import importlib
from libs.settings import *
from libs.common import save_to_influxdb
import traceback
import time
import signal

import logging
logger = logging.getLogger('aut_run')


def init_argv():
    argvs=sys.argv
    script=argvs[1]
    new_argvs={
        'script':script,
    }
    key=None
    for arg in argvs[2:]:
        if arg.startswith('-'):
            key=arg[2:]
        else:
            if key:
                if key in new_argvs:
                    if isinstance(new_argvs[key], list):
                        new_argvs[key].append(arg)
                    else:
                        new_argvs[key]=[new_argvs[key],arg]
                else:
                    new_argvs[key]=arg
            key=None
    return new_argvs



def execute():
    argvs=init_argv()
    send='no'
    logger.info(argvs)
    if 'send' in argvs:
        if argvs['send']=='yes':
            send='yes'
    timeout=7200
    if 'timeout' in argvs:
        timeout =int(argvs['timeout'])

    module=argvs['script'][:-3]
    module=module.replace('/','.')
    start_time=time.time()*1000
    logger.info('new job start: %s' % argvs['script'])
    full_module_name = module
    ## compatiable module name with "script" prefix
    if not full_module_name.startswith("scripts."):
        full_module_name = 'scripts.' + full_module_name
    module_app=importlib.import_module(full_module_name)
    result=0
    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(timeout)
    try:

        aut_run_app=module_app.aut_run_app(**argvs)
        run = getattr(aut_run_app, "run", None)
        if not callable(run):
            run = getattr(aut_run_app, "run_app", None)
        ## execute run method.
        metrics = run()
        logger.debug(metrics)
        status='ok'
    except:
        tb=traceback.format_exc()
        logger.error('exception caught when running app %s' % module)
        logger.error(tb)
        status='fail'
    end_time=time.time()*1000
    duration=int(end_time-start_time)
    logger.info('job end: script=%s status=%s total_time=%d metrics_sent_count=%d' % (argvs['script'], status, duration, result))
    i_data={
        "measurement": "aut_run_script_latency",
        "tags": {
            "script": argvs['script'],
            "status": status
        },

        "fields": {
            "latency_ms": duration

        }
    }

    save_to_influxdb('devops',[i_data])

def signal_handler(signum, frame):
    logger.error("timeout when running the script")
    raise Exception("Timed out!")

if __name__ == '__main__':
    execute()
