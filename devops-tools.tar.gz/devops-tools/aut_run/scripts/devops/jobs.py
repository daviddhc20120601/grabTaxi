#-*-coding:utf-8-*-
#import urllib2
import requests
import time
import datetime
import os
import traceback
import yaml
import json
import croniter

import logging
logger = logging.getLogger(__name__)

'''
this script will compare the job config file jobs.yaml before and after git pull from visenze monitor and update to the scheduler if there is any change.

python virelic.py misc/jobs.py

'''

url="http://localhost:4400"
current_dir=os.getcwd()

class virelic_app():
    def __init__(self,**kargs):
        self.event=kargs
        self.metrics=[]
    def run(self):
        '''
        change this function for metrics collection
        '''
        logger.info(self.event)

        #config=os.path.abspath(__file__)
        #config=config[:-3] + ".yaml"
        #config=config.replace("..yaml",".yaml")


        config=current_dir + "/jobs.yaml"
        if 'DEPLOY_ENV' in self.event:
            config= "%s/jobs_%s.yaml" % (current_dir,self.event['DEPLOY_ENV'])

        with open(config, "r") as f:
            settings = yaml.load(f)
        f.close()

        for job in settings['jobs']:
            logger.info("%s" % json.dumps(job))

        try:
            os.system('git pull --no-edit visenze develop')
            #os.system('git pull --no-edit origin monitor')
        except:
           tb=traceback.format_exc()
           logger.error('exception caught when running git pull command')
           logger.error(tb)

        with open(config, "r") as f:
            settings_new = yaml.load(f)
        f.close()
        i_new=0
        for job_new in settings_new['jobs']:
            i=0
            job_change=True
            job_find=False
            for job in settings['jobs']:
                if job_new['name']==job['name']:
                    job_find=True
                    if settings_new['jobs'][i_new]==settings['jobs'][i]:
                        job_change=False
                        break
                i+=1
            if job_change:
                add_job(settings_new['jobs'][i_new],'update')
            elif not job_find:
                add_job(settings_new['jobs'][i_new],'add')
            i_new +=1

        i=0
        for job in settings['jobs']:
            job_find=False
            for job_new in settings_new['jobs']:
                if job_new['name']==job['name']:
                    job_find=True
                    break
            if not job_find:
                delete_job(job['name'])
            i+=1
            

def add_job(job,action):
    _job=job
    logger.info("%s",json.dumps(_job))
    schedule=_job['schedule']
    now = datetime.datetime.utcnow()
    cron = croniter.croniter(schedule, now)
    next_time1=cron.get_next(datetime.datetime)
    delta=datetime.timedelta(hours=8)
    next_time1=next_time1-delta
    next_time2=cron.get_next()
    next_time3=cron.get_next()
    interval=next_time3-next_time2
    schedule='R/%s/PT%dS' % (next_time1.isoformat() + ".000Z", interval)
    _job['schedule']=schedule
    _job['command']="cd %s && %s" % (current_dir, _job['command'])
    logger.info("%s job %s" % (action,_job['name']))
    logger.info("%s",json.dumps(_job))
    headers={'content-type':'application/json', 'accept':'application/json'}
    response=requests.post("%s/scheduler/iso8601" % url, headers=headers, data=json.dumps(_job))
    logger.info("action=%s job=%s status=%d" % (action,_job['name'],response.status_code))

def delete_job(job_name):
    logger.info("delete job %s" % job_name)
    response=requests.delete("%s/scheduler/job/%s" % (url,job_name))
    logger.info("action=delete job=%s status=%d" % (job_name,response.status_code))
