#-*-coding:utf-8-*-

import requests
import time,datetime
import os
import json
import traceback
from libs.web_status import request_web
from libs.settings import *
import yaml
import Queue
import hashlib
import glob
import threading
from libs.common import *
import logging
import json


logger = logging.getLogger(__name__)

worker_queue = Queue.Queue()
idb_data=[]

failed_jobs=[]
failed_hashs=[]

def worker(q):
    while True:
        try:
            params = q.get()
            result=request_web(params)
            
            i_data={
                "measurement": "web_status",
                "tags": {
                    "project": params['project'],
                    "name": params['name'],
                    "method": params['method'],
                    "url": params['url'],
                    "status": result['status'],
                    "status_code": result['status_code'],
                    "msg":result['msg']
                },

                "fields": {
                    "total_time": result['total_time']

                }
            }
            if result['status_code'] !=200 or result['status'].lower() != 'ok':
                url_hash=hashlib.sha224(params['url']).hexdigest()
                item={
                         'url':params['url'],
                         'project': params['project'],
                         'status_code':result['status_code'],
                         'status': result['status'],
                          'msg': result['msg'],
                         'url_hash':url_hash
                }
                failed_hashs.append(url_hash)
                failed_jobs.append(item)

            idb_data.append(i_data)

        except:
            logger.error( "worker exceptions found, exiting")
            tb=traceback.format_exc()
            logger.error( tb)
            
        finally:
            q.task_done()

class aut_run_app():
    def __init__(self,**kargs):
        self.event=kargs
        self.metrics=[]
    def run(self):
        '''
        change this function for metrics collection
        '''
        logger.info(self.event)

        for i in range(5):
            pw1 = threading.Thread(target=worker, args=(worker_queue,))
            pw1.daemon = True
            pw1.start()

        script_file=os.path.abspath(__file__)
        config=script_file[:-3] + ".yaml"
        config=config.replace("..yaml",".yaml")
        with open(config, "r") as f:
            settings = yaml.load(f)
        f.close()
        

        for job in settings['jobs']:

            params={
                "method":job['method'],
                "url": job['url'],
                "auth": job['auth'],
                "data": job['data'],
                "status":job['status'],
                "project":job['project'],
                "name":job['name'],
                
            }
            worker_queue.put(params)


        try:
            worker_queue.join()
        except:
            tb=traceback.format_exc()
            logger.error( tb )
        if len(idb_data)>0:
            save_to_influxdb('devops',idb_data)


        for job in failed_jobs:
            dingding_msg = {
                "msgtype": "link",
                "link": {
                    "text": job['project'] + ": " + job['msg'],
                    "title": ' %s - %s' % (job['status'],job['url']),
                    "picUrl": "http://jenkins.lzd.co/static/f7ca4433/images/32x32/red.png",
                    "messageUrl": job['url']
                }
            }
            flag_file='/var/tmp/web_check_' + job['url_hash']
            if not os.path.exists(flag_file):
                fh=open(flag_file,'w')
                fh.write(str(job) + "\n")
                fh.close()

                if job['project'] in dingding_access_token:
                    send_dingding_link(dingding_access_token[job['project']],dingding_msg)
                else:
                    send_dingding_link(dingding_access_token['devops'],dingding_msg)
                
        file_list=glob.glob("/var/tmp/web_check_*")
        for item in file_list:
            if item[19:] not in failed_hashs:
                with open(item) as json_data:
                    job = json.load(json_data)

                os.remove(item)

                dingding_msg = {
                    "msgtype": "link",
                    "link": {
                        "text": job['project'] + ": " + job['msg'],
                        "title": 'ok - %s' % job['url'],
                        "picUrl": "http://jenkins.lzd.co/static/f7ca4433/images/32x32/blue.png",
                        "messageUrl": job['url']
                    }
                }
                if job['project'] in dingding_access_token:
                    send_dingding_link(dingding_access_token[job['project']],dingding_msg)
                else:
                    send_dingding_link(dingding_access_token['devops'], dingding_msg)

