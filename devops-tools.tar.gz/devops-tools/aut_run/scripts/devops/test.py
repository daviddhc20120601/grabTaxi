#-*-coding:utf-8-*-

import requests
import time,datetime
import os
import json
import traceback
from libs.web_status import request_web
from libs.settings import *
import yaml
import Queue
import hashlib
import glob
import threading
from libs.common import *
import logging
import json


logger = logging.getLogger(__name__)


class aut_run_app():
    def __init__(self,**kargs):
        self.event=kargs
        self.metrics=[]
    def run(self):
        '''
        change this function for metrics collection
        '''
        logger.info(self.event)
        print "\ni am  a test\t\n"
