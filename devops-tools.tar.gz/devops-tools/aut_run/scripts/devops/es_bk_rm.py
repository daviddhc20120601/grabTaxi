#-*-coding:utf-8-*-

import logging
from datetime import datetime
import time
from elasticsearch import Elasticsearch
es = Elasticsearch("http://127.0.0.1:9200")



logger = logging.getLogger(__name__)

def bk_rm(datetime_0):


class aut_run_app():
    def __init__(self,**kargs):
        self.event=kargs
        self.metrics=[]
    def run(self):
        '''
        change this function for metrics collection
        '''
        logger.info(self.event)
        print "\n i am starting \t\n"

	
