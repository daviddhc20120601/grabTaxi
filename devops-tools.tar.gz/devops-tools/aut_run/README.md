# aut_run

## What is this?

This tool is targeting to be an python scripts framework to run metrics collection and schedule task script.

## How it works?

- users write a custom scripts based on the framework standard and return metrics.

- define a schedule job file in the jobs.yaml.

- back ground service find the job file and add to scheduler and begin to run the jobs frequently.

- aut_run will send metrics that returned by the script to influxdb for dashboard presenting and monitoring.

## Requirements

- install the required module before using the freamework. #pip install -r requirement.txt

## Folder structure

- `libs` share modules in libs.

- `scripts` scripts will be put into a dedicated project folder.
  - devops: scripts for project devops
  - c360: scripts for project c360
  - retail: scripts for project retail
  - ...

- `aut_run.py`: the entry point of the framework.

- `logging.conf`: logging format configuration.





example: run below jobs every 5 minutes.
```sh

    #python aut_run.py scripts/devops/web_check.py

```


