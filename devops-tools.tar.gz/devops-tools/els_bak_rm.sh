#docker run -p 9200:9200 -p 9300:9300 -p 5601:5601 -e "discovery.type=single-node" docker.elastic.co/elasticsearch/elasticsearch:6.2.3

curl -X GET "http://localhost:9200/_cat/indices/_all"


curl -XPOST 'localhost:9200/_snapshot/_mybackup/my_snapshot_as/_restore?pretty'


