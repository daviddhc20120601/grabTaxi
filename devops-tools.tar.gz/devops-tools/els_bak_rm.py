from datetime import datetime
import time
from elasticsearch import Elasticsearch
es = Elasticsearch("http://127.0.0.1:9200")


index_name = "logs-devops-django-2018.02.20"
doc = {
    'author': 'kimchy',
    'text': 'Elasticsearch: cool. bonsai cool.',
    'timestamp': datetime.now(),
}
res = es.index(index=index_name, doc_type='tweet', id=1, body=doc)
print res


print es.snapshot.create(repository='_mybackup', snapshot='my_snapshot_%s'%('asdfs') )


###wait till done
time.sleep(10*60)

print es.indices.get_alias()

#print es.indices.delete(index=index_name,ignore=[400,404])



