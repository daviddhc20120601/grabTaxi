# Purpose:

kapacitor is our tools to monitor the influxdb data, and kapacitor can post data to an endpoint. this tool is to resolve:
- post data via http_proxy
- format the alert data send to the dingding message



# How to use the docker

```sh
#docker run --name=dingding_proxy --restart=always -d -e no_proxy=yes -p 5000:5000 dingding_proxy
```

# parameter
- access_token: dingding robot access token
- alert_type: if set to system, it will link to grafana system dashboard. if not set, it will link to the alert.


# Test Example:
```sh
#cat /tmp/a
{
	"id": "test",
	"message": "test from alfred",
	"details": "test detail",
	"time": "2018-03-22T02:08:55Z",
	"duration": 0,
	"level": "CRITICAL",
	"data": {
		"series": [{
			"name": "cpu",
			"tags": {
				"cpu": "cpu-total",
				"env": "production",
				"host": "alyn-srv-01030.lzd.io",
				"project": "qcportal",
				"region": "sg"
			},
			"columns": ["time", "value"],
			"values": [
				["2018-03-22T02:08:55Z", 68.00350918144039]
			]
		}]
	},
	"previousLevel": "OK"
}

#curl http://localhost:5000/robot/send?access_token=c65d5cea4259a9da766c15e8791bae018354fea18437ec084057aa849a30c3e7&alert_type=system \
-d @/tmp/a -H "Content-Type: application/json"

```

#  docker images build

see [jenkins job](http://jenkins.lzd.co/view/devops/job/devops-tools-dingding_proxy-build/)
