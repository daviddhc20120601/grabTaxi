#!/usr/bin/python
"""
A simple dingding proxy server to send msg to dingding api server. Usage:
http://hostname:port/p/(URL to be proxied, minus protocol)
For example:
http://localhost:8080/p/www.google.com

redirect dingding robot meg to dingding api server via http_proxy

"""
from flask import Flask, render_template, request, abort, Response, redirect
import requests
import logging
import json
import requests
import sys
import os
import traceback

proxies = {
  'http': 'http://alyn-srv-01031.lzd.io:8080',
  'https': 'http://alyn-srv-01031.lzd.io:8080',
}

if os.getenv('no_proxy'):
    if os.environ['no_proxy'].lower()=="yes":
        proxies=''


app = Flask(__name__.split('.')[0])
logging.basicConfig(level=logging.INFO)
CHUNK_SIZE = 1024
LOG = logging.getLogger("main.py")


@app.route('/robot/<path:url>', methods=['POST'])
def send(url):


    data = request.get_json()
    message=data['message']
    level=data['level']
    sub_data=data['data']
    value = sub_data['series'][0]['values'][0][1]
    access_token = request.args.get('access_token')

    LOG.info(data)

    host="not_defined"
    if request.args.get('alert_type'):
        alert_type=request.args.get('alert_type')
        if alert_type.lower()=="system":
            host=sub_data['series'][0]['tags']['host']
            import pdb;pdb.set_trace()

    dingding_msg = {
        "msgtype": "link",
        "link": {
            "text": message,
            "title": level,
            "picUrl": "",
            "messageUrl": ""
        }
    }
    if host == "not_defined":
        dingding_msg['link']['messageUrl']="http://aut-dashboard.lzd.co:8888/sources/1/alerts"
    else:
        dingding_msg['link']['messageUrl'] = "http://aut-dashboard.lzd.co:3000/dashboard/db/telegraf-system-dashboard?var-server=%s" % host

    LOG.info(dingding_msg)




    headers={"Content-Type": "application/json"}
    try:
        res=requests.post('https://oapi.dingtalk.com/robot/send?access_token=%s' % access_token, data=json.dumps(dingding_msg),headers=headers,proxies=proxies)
        if res.status_code != 200:
            LOG.error(res.text)
        else:
            LOG.info("sending to dingtalk robot successfully. ret code:%d" % res.status_code)
        return res.text
    except:
        tb = traceback.format_exc()
        LOG.error(tb)



if __name__ == '__main__':
    app.run(host="0.0.0.0",port=5000)



